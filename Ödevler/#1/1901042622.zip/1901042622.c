#include<stdio.h>
#include<math.h>

void find_root();
void find_newtonian_root();
int  find_multiple_closest(int a, int b);

int main()
{
	int a,b;         //input - for 3rd part.// 		
	int result;     //output - result of the function.//

	find_root();
	find_newtonian_root();

	printf("\nEnter the first integer.\n");   //get the numbers.//
	scanf("%d",&a);
	printf("Enter the second integer.\n");
	scanf("%d",&b);

	result = find_multiple_closest(a,b);


	if (a%b == 0)   //don't need to find the closest because a is divisible without remainder.//
	{
		printf("Closest number to %d that is multiple of %d is itself.\n",a,b);   //display the result.//
	}

	else   
	{

		printf("Closest number to %d that is multiple of %d is %d.\n",a,b,result);
	}

return (0);

}

void find_root()
{
	int a, b, c;        		//input - coefficients of the equation.//
	float root1,root2;          //output - roots of the equation.//
	
	printf("Please enter the first coefficient.\n");   //get the coefficients.//
	scanf("%d",&a);
	printf("Please enter the second coefficient.\n");
	scanf("%d",&b);
	printf("Please enter the third coefficient.\n");
	scanf("%d",&c);

	double discriminant = (b*b)-(4*a*c);                    //mathematical formula of discriminant.//
	double root_of_discriminant = sqrt(discriminant);       //take the root of the discrimnant to use in the mathematical equation below.//


	root1= ((-b)+(root_of_discriminant))/(2*a);   			//the equation to find the roots.//
	root2= ((-b)-(root_of_discriminant))/(2*a);
		

		if (discriminant>=0)    
		{
			printf("Your equation %+dx^2 %dx %+d does have real roots: {%.2f,%.2f} \n",a,b,c,root1,root2); //display the roots.//
		}
		

		else   
		{
			printf("Your equation %+dx^2 %+dx %+d does not have any real roots.\n",a,b,c);
		}


}

void find_newtonian_root()
{

	int a, b, c;  //input - coefficients of the equation.//
	float x;      //input&output - initial guess.//
	

	
	
	printf("\nPlease enter the first coefficient.\n");   //get the coefficients.//
	scanf("%d",&a);
	printf("Please enter the second coefficient.\n");
	scanf("%d",&b);
	printf("Please enter the third coefficient.\n");
	scanf("%d",&c);
	printf("Please enter the initial.\n");  //get the initial guess.//
	scanf("%f",&x);

	float fx = (a*x*x)+(b*x)+c;                                 //output - compute the f(x).//
	float dfx = 2*a*x + b;                                      //compute the derivative of f(x).//
	double discriminant = (b*b)-(4*a*c);                        //compute the discriminant.//
	double root_of_discriminant = sqrt(discriminant);           //compute the root of the discriminant.//
	float root1= ((-b)+(root_of_discriminant))/(2*a);           //compute the roots.//
	float root2= ((-b)-(root_of_discriminant))/(2*a);
	double root;                                                //closest root to initial guess.//  
	double difference;                                          //output - difference between initial guess and the closest root of the equation.//
	
	

	if(fabs(x-root1)<fabs(x-root2))                           
	{                                                           //compare the distances between inital guess and roots.//                                                       
		root=root1;                                             //smallest distance is the one it'll use for difference.//                                            
	}

	else
	{
		root=root2;
	}

	                                                            //THIS PART WILL BE REPEATED WITH THE 5 NEW X 5 TIMES.//
	x = x- (fx/dfx);                                            //compute Newton and Raphson's Method's equation and get the new value of "x".//
	difference = x-root;                                        //compute the difference with the new "x".//
	fx = (a*x*x)+(b*x)+c;                                       //compute the f(x) with the new "x".//
	dfx = 2*a*x + b;                                            //compute the derivative of f(x) with the new "x".//

	printf("Your equation is %+dx^2 %+dx %+d  and iterations are\n\n Step\t x\t  f(x)\t     difference\n\n",a,b,c);  //display the iteration steps.//
	printf("x1\t %.4f\t %.5f\t %.4f\n",x,fx,difference);        //display the step,x,f(x),difference.//
	                                                            //THIS PART WILL BE REPEATED WITH THE NEW VALUES.//
	x = x- (fx/dfx);
	difference = x-root;
	fx = (a*x*x)+(b*x)+c;
	dfx = 2*a*x + b;
	printf("x2\t %.4f\t %.5f\t %.4f\n",x,fx,difference);

	x = x- (fx/dfx);
	difference = x-root;
	fx = (a*x*x)+(b*x)+c;
	dfx = 2*a*x + b;
	printf("x3\t %.4f\t %.5f\t %.4f\n",x,fx,difference);

	x = x- (fx/dfx);
	difference = x-root;
	fx = (a*x*x)+(b*x)+c;
	dfx = 2*a*x + b;
	printf("x4\t %.4f\t %.5f\t %.4f\n",x,fx,difference);

	x = x- (fx/dfx);
	difference = x-root;
	fx = (a*x*x)+(b*x)+c;
	dfx = 2*a*x + b;
	printf("x5\t %.4f\t %.5f\t %.4f\n",x,fx,difference);

}

	int find_multiple_closest(int a, int b)
{	
	int k;                              //quotient value of a/b.//   
	int closest_lower, closest_upper;   //output - closest multiple values.//
	
	
		k=a/b;                         //even if the answer is fractional number it will get it as a integer.//
		closest_lower=k*b;             //so the quotient value*divisor value will give closest lower value.//
		closest_upper=(k+1)*b;         //quotient value + 1 will give closest upper value.//

		if (fabs(a-closest_lower)<fabs(a-closest_upper))  //compare the distances between 'a' and the closest values.//
		{
			return (closest_lower);                       //smallest distance is the one it'll use for closest value.//

		}

		else
		{
			return (closest_upper);
		}
}
	






