#include<stdio.h>
#include<math.h>

int number_length(int number);
int find_digit(int number, int index);

int main()
{

	int number=0;  	//input//
	int index =0;   //input//
	int length=0;  	//output - result of the number_length function.//
	int result=0;  	//output - result of the find_digit function.//
	int capacity=0; //total digits when the number written 100 times next to each other.//

	printf("Enter a number (maximum 6 digits):\n");  //get the number.//
	scanf("%d",&number);

	length = number_length(number);
	capacity = length*100;      //computes capacity.//

	printf("Your number has %d digits.\n\n",length);         //display the length.//

	printf("When your number is written 100 times next to each other, which digit of this number would you like to see?\n");
	scanf("%d",&index);

	result = find_digit(number,index);

	if (index>capacity)             //when user wants to see number that off the capacity.//
	{
		printf("\nSorry, when your number is written 100 times next to each other, there's no %d.th digit.\n",index);
	}
	else
	{	
		printf("\n%d.th digit of the big number sequence:%d\n",index,result);     //display the desired digit.//
	}

	return (0);

}

int number_length(int number)
{
	double length;

	if (number == 0)    //log0 is undefined but number 0 has 1 digit.//
	{
		return(1);
	}

	else
	{
		length = log10(number) + 1;     //log (base 10) calculates (length - 1).//
		return(length);
	}   
}                                        

int find_digit(int number, int index)
{
	int length;       
	int mod;
	int result=0;                       //result of this function.
 
	length = number_length(number);   //computes lenght.//
	mod = index%length;               //it doesn't have to look repatitive part anymore.//

	if(mod == 0)
	{
		mod = length;                 //if we use "0" pow function calculates 10^6 and this cause number to be "0".//
	}

	length = length - mod;             //to compute the desired digit, next step this will use as exponent.//
	result = number/pow(10,length);   //removes the undesired part of the number.//
	result = result%10;               //computes the desired digit.//
	
	
	return (result);
}
