#include<stdio.h>

int main()
{
	float eur_to_try = 6.69;
	float usd_to_try = 6.14;
	float try_to_eur = 1/6.69;
	float try_to_usd = 1/6.14;

	float amount;    //input - money amount of the user.//
	int currency;    //input//
	int selection;  //input - exchanging selection.//

	printf("***** Welcome to ABC Exchange Office *****\n");
	printf("Enter your amount:\n");     //get the amount.//
	scanf("%f",&amount);
	printf("\nPlease select your currency:\n1.Turkish Lira\n2.Euro\n3.Dollar\n");     //get the currency.//
	scanf("%d",&currency);

	switch(currency){

		case 1:
		printf("\nYou have %f Turkish Liras.\n",amount);            //display the amount and currency.//
		printf("Choose which currency you want to convert.\n");     //get the selection.//
		scanf("%d",&selection);

		switch(selection){

			case 1:
			printf("You have %f Turkish Liras.\n",amount);        //display the conversion.//
			break;

			case 2:
			printf("You have %f Euros.\n",(amount*try_to_eur));
			break;

			case 3:
			printf("You have %f Dollars.\n",(amount*try_to_usd));
			break;

			default: 
			printf("Your selection is invalid.\n");
			break;

			}

		break;

		case 2:
		printf("\nYou have %f Euros.\n",amount);
		printf("Choose which currency you want to convert.\n");
		scanf("%d",&selection);

		switch(selection){

			case 1:
			printf("You have %f Turkish Liras.\n",(amount*eur_to_try));
			break;

			case 2:
			printf("You have %f Euros.\n",amount);
			break;

			case 3:
			printf("You have %f Dollars.\n",(amount*eur_to_try*try_to_usd));
			break;

			default: 
			printf("Your selection is invalid.\n");
			break;
			}

		break;

		case 3:
		printf("\nYou have %f Dollars.\n",amount);
		printf("Choose which currency you want to convert.\n");
		scanf("%d",&selection);

		switch(selection){

			case 1:
			printf("You have %f Turkish Liras.\n",(amount*usd_to_try));
			break;

			case 2:
			printf("You have %f Euros.\n",(amount*usd_to_try*try_to_eur));
			break;

			case 3:
			printf("You have %f Dollars.\n",amount);
			break;

			default: 
			printf("Your selection is invalid.\n");
			break;
			}

		break;

		default:
		printf("Your selection is invalid.\n");
		break;

		}

return 0;

}
