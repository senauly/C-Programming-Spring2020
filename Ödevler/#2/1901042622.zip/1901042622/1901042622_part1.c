#include <stdio.h>
#include <math.h>

int draw_triangle(int side1,int side2, int side3);
void type_triangle(int side1,int side2, int side3);
int perimeter_triangle(int side1,int side2, int side3);
double area_triangle(int side1,int side2, int side3,int perimeter);

int main()
{
	int side1, side2, side3;  //input - sides of a triangle.//
	int result;              //result of the draw_triangle function.//
	int perimeter;          //output - result of the perimeter_triangle function.//
	double area;           //output - result of the area_triangle function.//


	printf("The lenght of first side:\n");     //get the side.//
	scanf("%d",&side1);
	printf("The lenght of second side:\n");
	scanf("%d",&side2);
	printf("The lenght of third side:\n");
	scanf("%d",&side3);

	result = draw_triangle(side1,side2,side3);
	perimeter = perimeter_triangle(side1,side2,side3);
	area = area_triangle(side1,side2,side3,perimeter);

	if (result == 0)
	{
		printf("\nAccording to the triangle inequality theorem, this triangle cannot be drawn.\n");   //display the result.//
	}

	else
	{
		printf("\nAccording to the triangle inequality theorem, this triangle can be drawn.\n");
		type_triangle(side1,side2,side3);                                                         //display the type of the triangle.//
		printf("The perimeter of the triangle: %d\n",perimeter);                                 //display the perimeter.//
		printf("The area of the triangle: %f\n",area);                                          //display the area.//
	}
}

int draw_triangle(int side1,int side2, int side3)
{
	if (side1+side2>side3 && side1+side3>side2 && side2+side3>side1)  //triangle inequality theorem.//
	{
		return (1);
	}

	else
	{
		return (0);
	}
}

void type_triangle(int side1,int side2, int side3)
{
	if (side1 == side2 && side1 == side3 && side2 == side3)                                     //equilateral triangle condition.//
	{   
		printf("It is a equilateral triangle.\n");
	}

	else if (side1 == side2 || side1 == side3 || side2 == side3)     //isosceles triangle condition.//
	{
		printf("It is a isosceles triangle.\n");
	}

	else if (side1 != side2 && side1 != side3 && side2 != side3)     //scalene triangle condition.//
	{
		printf("It is a scalene triangle.\n");
	}
}

int perimeter_triangle(int side1,int side2, int side3)
{
	int perimeter; //output - perimeter of the triangle.//
	perimeter = side1 + side2 + side3;     //compute the perimeter.//

	return (perimeter);
}

double area_triangle(int side1,int side2, int side3,int perimeter)
{
	double p; //half of the perimeter.//
	double area; //output - area of the triangle.//

	p = perimeter/2.0;
	area = sqrt(p*(p-side1)*(p-side2)*(p-side3));     //compute the area.//
	
	return (area);
}